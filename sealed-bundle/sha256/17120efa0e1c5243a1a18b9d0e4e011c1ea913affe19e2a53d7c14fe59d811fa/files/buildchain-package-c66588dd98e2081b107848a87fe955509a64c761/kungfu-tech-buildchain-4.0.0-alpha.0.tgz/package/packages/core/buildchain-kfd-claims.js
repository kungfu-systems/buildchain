import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { createBuildchainContractWorld, sha256Json } from "./buildchain-contract.js";
import {
  BUILDCHAIN_PUBLIC_SURFACE_AUDIT_CONTRACT,
  collectPublicSurfaceReverseAudit,
} from "./public-surface-audit.js";
import { normalizeKfd3DistributionDeclaration } from "./kfd3-surface-register.js";
import { BUILDCHAIN_AGENT_MANUALS } from "./buildchain-agent-manuals.js";

export { BUILDCHAIN_AGENT_MANUALS } from "./buildchain-agent-manuals.js";

export const BUILDCHAIN_KFD_CLAIM_REGISTRY_CONTRACT = "kungfu-buildchain-kfd-claim-registry";
export const BUILDCHAIN_KFD_COLLABORATION_INTERFACE_CONTRACT = "kungfu-buildchain-kfd-collaboration-interface";

const SITE_CONTRACT_FILES = Object.freeze([
  "dist/site/buildchain-site.json",
  "dist/site/site-manifest.json",
  "dist/site/publication-registry.json",
  "dist/site/page-registry.json",
  "dist/site/capability-registry.json",
  "dist/site/cli-registry.json",
  "dist/site/manual-registry.json",
  "dist/site/node-api-registry.json",
  "dist/site/workflow-registry.json",
  "dist/site/controller-registry.json",
  "dist/site/publication-authority-registry.json",
  "dist/site/public-surface-audit.json",
  "dist/site/release-model.json",
  "dist/site/artifact-schemas.json",
  "dist/site/buildchain-contract.json",
  "dist/site/product-mechanism.json",
  "dist/site/release-provenance.json",
  "dist/site/agent-index.json",
  "dist/site/kfd-claims.json",
  "dist/site/kfd-upstream-aggregate.json",
]);

const SCHEMA_AND_STANDARD_FILES = Object.freeze([
  "packages/core/kfd-gate.js",
  "packages/core/release-passport.js",
  "packages/core/github-artifact-attestation.js",
  "packages/core/buildchain-contract.js",
  "packages/core/controller-evidence.js",
  "packages/core/publication-authority.js",
  "packages/core/publication-control-plane-audit.js",
  "packages/core/buildchain-publication-authority.js",
  "packages/core/github-governance-authority.js",
  "packages/core/buildchain-kfd-claims.js",
  "packages/core/kfd3-surface-register.js",
  "packages/core/public-surface-audit.js",
  "dist/site/artifact-schemas.json",
  "dist/site/buildchain-contract.json",
]);

const WORKFLOW_AND_ACTION_FILES = Object.freeze([
  ".github/workflows/.build.yml",
  ".github/workflows/.release-candidate-promote.yml",
  ".github/workflows/release-candidate-promote.yml",
  ".github/workflows/buildchain-ref-promotion.yml",
  ".github/workflows/github-artifact-attestation.yml",
  "actions/github-artifact-attestation/action.yml",
  "actions/github-artifact-attestation/index.js",
  ".github/workflows/release-propagation.yml",
  "actions/macos-credential-island/action.yml",
  "actions/macos-credential-island/index.js",
  "actions/promote-buildchain-ref/action.yml",
  "actions/promote-buildchain-ref/index.js",
]);

const EXTRA_KFD1_FILES = Object.freeze([
  "package.json",
  "bin/buildchain.mjs",
  "packages/core/index.js",
  "packages/core/homebrew.js",
  "packages/core/build-facts.js",
  "packages/core/kfd3-surface-register.js",
  "packages/core/release-propagation.js",
  "scripts/generate-site-bundle.mjs",
  "scripts/ensure-github-release.mjs",
]);

function publicSurfaceReverseAudit({ root }) {
  if (!fileExists(root, "bin/buildchain.mjs")) {
    return {
      schemaVersion: 1,
      contract: BUILDCHAIN_PUBLIC_SURFACE_AUDIT_CONTRACT,
      status: "unavailable",
      summary: { failureCount: 0 },
      enumerated: {
        cliCommands: [],
        workflowInputs: [],
        actionInputs: [],
        sitePages: [],
        docCommandRefs: [],
      },
      declared: {},
      comparison: {
        missingCliRegistry: [],
        missingWorkflowRegistry: [],
        missingActionRegistry: [],
        missingPageRegistry: [],
        unknownDocCommandRefs: [],
      },
      auditBoundary: {
        mode: "not-enumerated",
        scope: "Fixture or partial source tree without bin/buildchain.mjs",
        residualRisk: ["Reverse audit is only enforceable in a complete Buildchain source tree."],
      },
    };
  }
  return collectPublicSurfaceReverseAudit({ root });
}

function publicSurfaceAuditEvidence(root) {
  const relPath = "dist/site/public-surface-audit.json";
  const audit = publicSurfaceReverseAudit({ root });
  return {
    contract: BUILDCHAIN_PUBLIC_SURFACE_AUDIT_CONTRACT,
    path: relPath,
    status: audit.status,
    sha256: fileExists(root, relPath) ? sha256File(root, relPath) : "",
    summary: audit.summary,
    auditBoundary: audit.auditBoundary,
  };
}

function immediateReadmes(root, dir) {
  const absoluteDir = path.join(root, dir);
  if (!fs.existsSync(absoluteDir)) return [];
  return fs.readdirSync(absoluteDir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => `${dir}/${entry.name}/README.md`)
    .filter((relPath) => fileExists(root, relPath))
    .sort();
}

function publicDocumentationFiles(root) {
  return uniquePaths([
    ...BUILDCHAIN_AGENT_MANUALS.map((entry) => entry.path),
    "README.md",
    "packages/core/README.md",
    ...immediateReadmes(root, "actions"),
    ...immediateReadmes(root, "fixtures"),
  ]);
}

function readJson(root, relPath, fallback = {}) {
  const filePath = path.join(root, relPath);
  if (!fs.existsSync(filePath)) {
    return fallback;
  }
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function fileExists(root, relPath) {
  const filePath = path.join(root, relPath);
  return fs.existsSync(filePath) && fs.statSync(filePath).isFile();
}

function sha256File(root, relPath) {
  return crypto.createHash("sha256").update(fs.readFileSync(path.join(root, relPath))).digest("hex");
}

function uniqueById(entries) {
  const seen = new Set();
  return entries.filter((entry) => {
    if (seen.has(entry.id)) return false;
    seen.add(entry.id);
    return true;
  });
}
function uniquePaths(paths) {
  return [...new Set(paths.filter(Boolean))].sort();
}

function fileEvidence(root, relPath, extra = {}) {
  const sha256 = fileExists(root, relPath) ? sha256File(root, relPath) : "";
  return {
    id: extra.id || relPath,
    path: relPath,
    sha256,
    digest: sha256 ? `sha256:${sha256}` : "",
    ...extra,
  };
}

function packageJson(root) {
  return readJson(root, "package.json", {});
}

function sourceMetadata({ root, sourceSha = "" } = {}) {
  const pkg = packageJson(root);
  return {
    repo: "kungfu-systems/buildchain",
    ref: sourceSha,
    package: pkg.name || "@kungfu-tech/buildchain",
  };
}

function runtimeContractSummary({ root = process.cwd() } = {}) {
  const contractWorld = createBuildchainContractWorld({ root });
  return {
    contract: contractWorld.contract,
    compatibilityDigest: contractWorld.compatibilityDigest,
    majorLine: contractWorld.majorLine,
  };
}

function surface(id, kind, relPath, extra = {}) {
  return {
    id,
    name: extra.name || id,
    kind,
    sourcePath: relPath,
    evidencePath: relPath,
    availability: "shipped",
    visibility: "public",
    participantFacing: true,
    public: true,
    ...extra,
  };
}

export function createBuildchainPublicClaimDefinitions() {
  return [
    {
      id: "claim:buildchain-kfd-release-passport-support",
      claim: "Buildchain release passports support KFD-1 self contract verification, KFD-2 public release claim audits, and KFD-3 collaboration-interface trust proofs.",
      sourcePaths: [
        "packages/core/release-passport.js",
        "packages/core/kfd-gate.js",
        "packages/core/buildchain-kfd-claims.js",
        "docs/release-passport.md",
      ],
      artifactPaths: [
        "dist/site/buildchain-contract.json",
        "dist/site/kfd-claims.json",
        "dist/site/artifact-schemas.json",
      ],
    },
    {
      id: "claim:buildchain-agent-first-source-of-truth",
      claim: "The npm package ships Buildchain's agent-first manuals, Node API registry, site facts, and release model as the single source of truth for downstream sites and agents.",
      sourcePaths: [
        "scripts/generate-site-bundle.mjs",
        "packages/core/buildchain-kfd-claims.js",
        "packages/core/readme-badges.js",
        "docs/MAP.md",
        "docs/site-bundle-contract.md",
        "docs/cli.md",
        "docs/readme-badges.md",
      ],
      artifactPaths: [
        "dist/site/manual-registry.json",
        "dist/site/node-api-registry.json",
        "dist/site/page-registry.json",
        "dist/site/capability-registry.json",
        "dist/site/publication-registry.json",
        "dist/site/buildchain-site.json",
        "dist/site/site-manifest.json",
      ],
    },
    {
      id: "claim:buildchain-public-surface-reverse-audit",
      claim: "Buildchain fails closed when enumerable public CLI, workflow, action, site page, or documentation command surfaces are exposed without a matching machine registry entry.",
      sourcePaths: [
        "packages/core/public-surface-audit.js",
        "scripts/generate-site-bundle.mjs",
        "scripts/check-inventory.mjs",
        "bin/buildchain.mjs",
      ],
      artifactPaths: [
        "dist/site/public-surface-audit.json",
        "dist/site/cli-registry.json",
        "dist/site/workflow-registry.json",
        "dist/site/page-registry.json",
        "dist/site/kfd-claims.json",
      ],
    },
    {
      id: "claim:buildchain-kfd-3-surface-registration",
      claim: "Buildchain provides KFD-3 surface detection, registration, audit, witness, and query APIs so products can declare agent-facing public capability surfaces without hand-writing full witness registries.",
      sourcePaths: [
        "packages/core/kfd3-surface-register.js",
        "bin/buildchain.mjs",
        "docs/kfd-support.md",
        "docs/cli.md",
      ],
      artifactPaths: [
        "dist/site/cli-registry.json",
        "dist/site/node-api-registry.json",
        "dist/site/kfd-claims.json",
        "dist/site/public-surface-audit.json",
      ],
    },
    {
      id: "claim:buildchain-shifu-kfd-discovery",
      claim: "Buildchain exposes a versioned repository-layout discovery contract and KFD-3 distribution declarations so Shifu can locate the registry and determine jurisdiction without copying Buildchain layout paths.",
      sourcePaths: [
        "packages/core/buildchain-layout.js",
        "packages/core/buildchain-kfd-claims.js",
        "packages/core/kfd3-surface-register.js",
        "bin/buildchain.mjs",
        "scripts/build-standalone-binary.mjs",
        "docs/kfd-support.md",
      ],
      artifactPaths: [
        "dist/site/kfd-claims.json",
        "dist/site/cli-registry.json",
        "dist/site/node-api-registry.json",
      ],
    },
    {
      id: "claim:buildchain-readme-badge-facts",
      claim: "Buildchain README status badges are generated from repository-owned facts and verified release-passport evidence, not hand-maintained README prose.",
      sourcePaths: [
        "packages/core/readme-badges.js",
        "bin/buildchain.mjs",
        "docs/readme-badges.md",
        "docs/cli.md",
        "buildchain.toml",
      ],
      artifactPaths: [
        "dist/site/node-api-registry.json",
        "dist/site/manual-registry.json",
        "dist/site/buildchain-contract.json",
      ],
    },
    {
      id: "claim:buildchain-homebrew-distribution-index",
      claim: "Buildchain Homebrew tap support generates and verifies Formula metadata as a distribution-index projection of upstream release passport evidence.",
      sourcePaths: [
        "packages/core/homebrew.js",
        "bin/buildchain.mjs",
        "docs/homebrew.md",
        "docs/cli.md",
        "packages/core/buildchain-config.js",
      ],
      artifactPaths: [
        "dist/site/node-api-registry.json",
        "dist/site/manual-registry.json",
        "dist/site/buildchain-contract.json",
      ],
    },
    {
      id: "claim:buildchain-floating-contract-lock",
      claim: "Consumers using floating Buildchain refs can lock the observed runtime contract and receive drift checks before expensive build or publish work proceeds.",
      sourcePaths: [
        "packages/core/buildchain-contract.js",
        "scripts/buildchain-contract-lock.mjs",
        ".github/workflows/.build.yml",
        ".github/workflows/.release-candidate-promote.yml",
        ".github/workflows/release-candidate-promote.yml",
        "docs/reusable-build-surface.md",
      ],
      artifactPaths: [
        "dist/site/buildchain-contract.json",
        "dist/site/release-model.json",
      ],
    },
    {
      id: "claim:buildchain-semver-github-release",
      claim: "Semver promotion can create or update the public GitHub Release only after the publish transaction completes, and uploads Buildchain release passport/evidence assets while preserving the internal transaction exact tag.",
      sourcePaths: [
        "actions/promote-buildchain-ref/index.js",
        "actions/promote-buildchain-ref/action.yml",
        "scripts/ensure-github-release.mjs",
        ".github/workflows/.release-candidate-promote.yml",
        ".github/workflows/release-candidate-promote.yml",
        "docs/release-governance.md",
      ],
      artifactPaths: [
        "dist/site/release-model.json",
        "dist/site/workflow-registry.json",
      ],
    },
    {
      id: "claim:buildchain-release-propagation",
      claim: "Buildchain can propagate exact upstream releases as Family State v2 and WorkRef-bound, resumable downstream work that preserves protected review and completes only after production readback.",
      sourcePaths: [
        "packages/core/release-propagation.js",
        "scripts/release-propagation.mjs",
        ".github/workflows/release-propagation.yml",
        "docs/release-propagation.md",
      ],
      artifactPaths: [
        "dist/site/release-model.json",
        "dist/site/workflow-registry.json",
      ],
    },
    {
      id: "claim:buildchain-npm-publish-evidence",
      claim: "Buildchain npm publish transactions bind trusted publishing, package-set required artifacts, publish evidence, durable release state, and final release passports.",
      sourcePaths: [
        "scripts/npm-publish-transaction.mjs",
        "actions/promote-buildchain-ref/index.js",
        ".github/workflows/.release-candidate-promote.yml",
        ".github/workflows/release-candidate-promote.yml",
        "docs/publish-transaction.md",
      ],
      artifactPaths: [
        "dist/site/release-model.json",
        "dist/site/artifact-schemas.json",
      ],
    },
  ];
}

export function createBuildchainKfdSurfaceRegistry({ root = process.cwd() } = {}) {
  const pkg = packageJson(root);
  const reverseAudit = publicSurfaceReverseAudit({ root });
  const exports = Object.entries(pkg.exports || {})
    .filter(([specifier]) => !specifier.startsWith("./site/") && specifier !== "./package.json")
    .map(([specifier, target]) => surface(
      `export:${specifier}`,
      "package-export",
      String(target).replace(/^\.\//, ""),
      {
        packageExport: specifier,
        name: specifier === "." ? pkg.name : `${pkg.name}/${specifier.replace(/^\.\//, "")}`,
      },
    ));
  const manualTitles = new Map(BUILDCHAIN_AGENT_MANUALS.map((manual) => [manual.path, manual]));
  const docs = publicDocumentationFiles(root).map((relPath) => {
    const manual = manualTitles.get(relPath);
    return surface(`doc:${relPath}`, "documentation", relPath, {
      name: manual?.title || relPath,
      plane: manual?.plane || (relPath.startsWith("actions/") ? "action" : relPath.startsWith("fixtures/") ? "fixture" : "use"),
    });
  });
  const schemas = SCHEMA_AND_STANDARD_FILES.map((relPath) => surface(`schema:${relPath}`, "schema", relPath));
  const standardsMetadata = [
    surface("metadata:package-json", "standards-metadata", "package.json"),
    surface("metadata:buildchain-contract-world", "standards-metadata", "dist/site/buildchain-contract.json"),
    surface("metadata:kfd-claim-registry", "standards-metadata", "dist/site/kfd-claims.json"),
    surface("metadata:release-model", "standards-metadata", "dist/site/release-model.json"),
  ];
  const siteConsumptionContracts = SITE_CONTRACT_FILES.map((relPath) => surface(`site:${relPath}`, "site-consumption-contract", relPath));
  const controlSurfaces = WORKFLOW_AND_ACTION_FILES.map((relPath) => surface(`control:${relPath}`, relPath.includes("actions/") ? "action" : "workflow", relPath));
  const standaloneDistribution = surface(
    "distribution:buildchain-standalone",
    "binary-distribution",
    "scripts/build-standalone-binary.mjs",
    {
      name: "Buildchain standalone binary distribution",
      artifactPath: "dist/binary",
      evidencePath: ".github/workflows/binary-distribution.yml",
      distribution: normalizeKfd3DistributionDeclaration({
        registrar: "shifu",
        tasks: ["binary:build"],
        artifacts: [
          {
            kind: "binary",
            platform: "linux",
            pathGlob: "dist/binary/buildchain-x86_64-unknown-linux-gnu.tar.gz",
          },
          {
            kind: "binary",
            platform: "macos",
            pathGlob: "dist/binary/buildchain-aarch64-apple-darwin.tar.gz",
          },
          {
            kind: "binary",
            platform: "windows",
            pathGlob: "dist/binary/buildchain-x86_64-pc-windows-msvc.zip",
          },
        ],
      }, { surfaceId: "distribution:buildchain-standalone" }),
    },
  );
  const reverseEnumeratedSurfaces = uniqueById([
    ...reverseAudit.enumerated.cliCommands.map((entry) => surface(`cli:${entry.id}`, "cli-command", "bin/buildchain.mjs", {
      name: entry.usage,
      reverseAuditSource: entry.source,
    })),
    ...reverseAudit.enumerated.workflowInputs.map((entry) => surface(`workflow:${entry.id}`, "workflow", entry.path, {
      inputCount: entry.inputCount,
      inputs: entry.inputs,
      reverseAuditSource: ".github/workflows",
    })),
    ...reverseAudit.enumerated.actionInputs.map((entry) => surface(`action:${entry.id}`, "action", entry.path, {
      inputCount: entry.inputCount,
      inputs: entry.inputs,
      reverseAuditSource: "actions/*/action.yml",
    })),
    ...reverseAudit.enumerated.sitePages.map((entry) => surface(`site-page:${entry.id}`, "site-page", "dist/site/page-registry.json", {
      pagePath: entry.path,
      reverseAuditSource: "dist/site/page-registry.json",
    })),
  ]);
  return {
    schemaVersion: 1,
    contract: BUILDCHAIN_KFD_COLLABORATION_INTERFACE_CONTRACT,
    reverseAudit: publicSurfaceAuditEvidence(root),
    groups: {
      docs,
      schemas,
      standardsMetadata,
      packageExports: exports,
      siteConsumptionContracts,
      reverseEnumeratedSurfaces,
    },
    additionalSurfaces: [...controlSurfaces, standaloneDistribution],
    publicSurfaceCount: docs.length + schemas.length + standardsMetadata.length + exports.length + siteConsumptionContracts.length + reverseEnumeratedSurfaces.length + controlSurfaces.length + 1,
  };
}

export function createBuildchainKfdClaimRegistry({ root = process.cwd(), sourceSha = "" } = {}) {
  return {
    schemaVersion: 1,
    contract: BUILDCHAIN_KFD_CLAIM_REGISTRY_CONTRACT,
    product: {
      name: "Buildchain",
      package: packageJson(root).name || "@kungfu-tech/buildchain",
      repository: "kungfu-systems/buildchain",
    },
    source: {
      ...sourceMetadata({ root, sourceSha }),
      sourceModule: "packages/core/buildchain-kfd-claims.js",
    },
    runtimeContract: runtimeContractSummary({ root }),
    publicSurfaceReverseAudit: publicSurfaceAuditEvidence(root),
    publicClaims: createBuildchainPublicClaimDefinitions(),
    collaborationSurfaces: createBuildchainKfdSurfaceRegistry({ root }),
  };
}

export function createBuildchainKfd1Witness({ root = process.cwd(), sourceSha = "" } = {}) {
  const registry = createBuildchainKfdClaimRegistry({ root, sourceSha });
  const registrySha256 = sha256Json(registry);
  const paths = uniquePaths([
    ...publicDocumentationFiles(root),
    ...SCHEMA_AND_STANDARD_FILES,
    ...SITE_CONTRACT_FILES,
    ...WORKFLOW_AND_ACTION_FILES,
    ...EXTRA_KFD1_FILES,
  ]);
  return {
    schemaVersion: 1,
    id: "buildchain-self-contract-world",
    standard: "kfd-1",
    source: sourceMetadata({ root, sourceSha }),
    contractWorld: {
      id: "buildchain-runtime-contract-world",
      schemaId: "kungfu-buildchain-runtime-contract-world",
      digest: `sha256:${registrySha256}`,
      owner: "Buildchain maintainers",
      selfHosted: true,
    },
    standardContract: {
      id: "buildchain-kfd-claim-registry",
      path: "dist/site/kfd-claims.json",
      sha256: fileExists(root, "dist/site/kfd-claims.json") ? sha256File(root, "dist/site/kfd-claims.json") : "",
    },
    selfHostingBoundary: {
      mode: "self-hosted-standard-contract",
      sourceScope: "Buildchain KFD claim registry, release-passport schemas, manuals, Node API exports, workflows, and site-consumption contracts",
      artifactScope: "packaged npm files and release passport evidence assets",
      boundary: "declared source files must match packaged artifact bytes by sha256",
      residualRisk: [],
    },
    responsibility: {
      sourceContractOwner: "Buildchain maintainers",
      artifactVerificationOwner: "Buildchain KFD-1 release gate",
      releasePassportProofOwner: "Buildchain",
    },
    surfaces: paths.map((relPath) => {
      const sha256 = fileExists(root, relPath) ? sha256File(root, relPath) : "";
      return {
        name: relPath,
        sourcePath: relPath,
        sourceSha256: sha256,
        artifactPath: relPath,
        expectedSha256: sha256,
        byteForByte: true,
      };
    }),
  };
}

export function createBuildchainKfd3PrebuildWitness({ root = process.cwd(), sourceSha = "" } = {}) {
  const registry = createBuildchainKfdClaimRegistry({ root, sourceSha });
  const surfaces = createBuildchainKfdSurfaceRegistry({ root });
  const reverseAudit = publicSurfaceAuditEvidence(root);
  const digest = `sha256:${sha256Json(registry)}`;
  return {
    schemaVersion: 1,
    id: "buildchain-collaboration-interface",
    standard: "kfd-3",
    supportLevel: "release",
    source: sourceMetadata({ root, sourceSha }),
    sourceRegistry: {
      id: "Buildchain KFD claim registry",
      path: "dist/site/kfd-claims.json",
      sha256: fileExists(root, "dist/site/kfd-claims.json") ? sha256File(root, "dist/site/kfd-claims.json") : "",
    },
    collaborationInterfaceDigest: digest,
    collaborationInterface: {
      schemaVersion: 1,
      contract: BUILDCHAIN_KFD_COLLABORATION_INTERFACE_CONTRACT,
      product: {
        name: "Buildchain",
        repository: "kungfu-systems/buildchain",
        package: packageJson(root).name || "@kungfu-tech/buildchain",
      },
      participants: [
        { id: "human-release-operator", kind: "human" },
        { id: "agent-consumer", kind: "agent" },
        { id: "downstream-site", kind: "site" },
      ],
      docs: surfaces.groups.docs,
      schemas: surfaces.groups.schemas,
      standardsMetadata: surfaces.groups.standardsMetadata,
      packageExports: surfaces.groups.packageExports,
      siteConsumptionContracts: surfaces.groups.siteConsumptionContracts,
      reverseEnumeratedSurfaces: surfaces.groups.reverseEnumeratedSurfaces,
      surfaces: surfaces.additionalSurfaces,
      reverseAudit,
      closure: {
        classificationMode: reverseAudit.status === "passed" ? "closed-world" : "partial",
        reachableSurfaceMode: reverseAudit.status === "passed" ? "reverse-enumerated-boundary" : "declared-boundary",
        unclassifiedEntrypointsPolicy: "fail",
        nonExhaustivelyEnumerableSurfaces: reverseAudit.status === "passed" ? [] : [reverseAudit.auditBoundary?.scope || "public surface reverse audit unavailable"],
        explicitlyExemptedSurfaces: [],
      },
    },
    auditBoundary: {
      mode: reverseAudit.status === "passed" ? "closed-world" : "partial",
      scope: "Buildchain public human/agent release, workflow, package, and site-consumption surfaces",
      reachableSurfaceMode: reverseAudit.status === "passed" ? "reverse-enumerated-boundary" : "declared-boundary",
      unclassifiedPolicy: "fail",
      reverseAudit,
      nonExhaustivelyEnumerableSurfaces: reverseAudit.status === "passed" ? [] : [reverseAudit.auditBoundary?.scope || "public surface reverse audit unavailable"],
      explicitlyExemptedSurfaces: [],
    },
    residualRisk: [],
    responsibility: {
      registryFactsOwner: "Buildchain maintainers",
      artifactVerificationOwner: "Buildchain KFD-3 release gate",
      releasePassportProofOwner: "Buildchain",
    },
  };
}

export function createBuildchainKfd3ArtifactWitness({ root = process.cwd(), sourceSha = "" } = {}) {
  const registry = createBuildchainKfdClaimRegistry({ root, sourceSha });
  const surfaces = createBuildchainKfdSurfaceRegistry({ root });
  const reverseAudit = publicSurfaceAuditEvidence(root);
  return {
    schemaVersion: 1,
    id: "buildchain-collaboration-interface",
    standard: "kfd-3",
    sourceRegistry: {
      id: "Buildchain KFD claim registry",
      path: "dist/site/kfd-claims.json",
      sha256: fileExists(root, "dist/site/kfd-claims.json") ? sha256File(root, "dist/site/kfd-claims.json") : "",
    },
    collaborationInterfaceDigest: `sha256:${sha256Json(registry)}`,
    artifact: {
      name: packageJson(root).name || "@kungfu-tech/buildchain",
      path: "package.json",
      digest: fileExists(root, "package.json") ? `sha256:${sha256File(root, "package.json")}` : "",
    },
    docs: surfaces.groups.docs,
    schemas: surfaces.groups.schemas,
    standardsMetadata: surfaces.groups.standardsMetadata,
    packageExports: surfaces.groups.packageExports,
    siteConsumptionContracts: surfaces.groups.siteConsumptionContracts,
    reverseEnumeratedSurfaces: surfaces.groups.reverseEnumeratedSurfaces,
    surfaces: surfaces.additionalSurfaces,
    reverseAudit,
    auditBoundary: {
      mode: reverseAudit.status === "passed" ? "closed-world" : "partial",
      reachableSurfaceMode: reverseAudit.status === "passed" ? "reverse-enumerated-boundary" : "declared-boundary",
      reverseAudit,
      nonExhaustivelyEnumerableSurfaces: reverseAudit.status === "passed" ? [] : [reverseAudit.auditBoundary?.scope || "public surface reverse audit unavailable"],
    },
    verifier: {
      name: "Buildchain self KFD witness generator",
      source: "scripts/generate-buildchain-kfd-witnesses.mjs",
    },
  };
}

export function createBuildchainKfd2Claims({ root = process.cwd(), witnessFiles = {} } = {}) {
  const evidenceFiles = Object.entries(witnessFiles)
    .filter(([, relPath]) => relPath)
    .map(([id, relPath]) => fileEvidence(root, relPath, { id }));
  const reverseAuditEvidence = publicSurfaceAuditEvidence(root);
  return createBuildchainPublicClaimDefinitions().map((definition) => {
    const sourceBindings = uniqueById(definition.sourcePaths.map((relPath) => fileEvidence(root, relPath)));
    const artifacts = uniqueById(definition.artifactPaths.map((relPath) => fileEvidence(root, relPath)));
    const machineEvidence = [
      ...evidenceFiles,
      fileEvidence(root, "dist/site/public-surface-audit.json", {
        id: "public-surface-reverse-audit",
        contract: reverseAuditEvidence.contract,
        status: reverseAuditEvidence.status,
      }),
      { id: "buildchain-kfd-claim-definition", digest: `sha256:${sha256Json(definition)}` },
    ];
    return {
      id: definition.id,
      public: true,
      claim: definition.claim,
      sourceBindings,
      machineEvidence,
      hashes: {
        definitionSha256: sha256Json(definition),
        sourceBindingsSha256: sha256Json(sourceBindings),
        machineEvidenceSha256: sha256Json(machineEvidence),
        artifactsSha256: sha256Json(artifacts),
      },
      artifacts,
      verification: {
        result: "passed",
        method: "Buildchain self KFD claim registry and release witness generation",
      },
      auditBoundary: {
        mode: "closed-world",
        scope: "Buildchain declared public release claims for packaged docs, workflows, actions, Node exports, site facts, npm publish, GitHub Release, release propagation, and KFD passport support",
      },
      responsibility: {
        owner: "Buildchain maintainers",
        sourceOwner: "Buildchain maintainers",
        releasePassportProofOwner: "Buildchain",
      },
      residualRisk: [],
    };
  });
}
