#!/usr/bin/env node

const DEFAULTS = {
  buildWorkflowFile: "build-surface-fixture.yml",
  buildWorkflowName: "Build Surface Fixture",
  canaryRepository: "kungfu-systems/site-libkungfu-dev",
  canaryWorkflowFile: "buildchain-stable-canary.yml",
  canaryWorkflowName: "Buildchain Stable Canary",
  canaryStatusContext: "buildchain-canary/site-libkungfu-dev",
  pollAttempts: 80,
  pollIntervalMs: 15_000,
};

function text(value = "") {
  return String(value ?? "").trim();
}

function integer(value, fallback) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : fallback;
}

function bool(value, fallback = false) {
  if (value === undefined || value === null || value === "") return fallback;
  return ["1", "true", "yes", "on"].includes(text(value).toLowerCase());
}

function repository(value) {
  const normalized = text(value);
  if (!/^[^/\s]+\/[^/\s]+$/.test(normalized)) {
    throw new Error(`repository must be owner/repo, got ${value || "<empty>"}`);
  }
  return normalized;
}

function optionalSha(value, label) {
  const normalized = text(value);
  if (normalized && !/^[0-9a-f]{40}$/i.test(normalized)) {
    throw new Error(`${label} must be an exact 40-character commit SHA, got ${normalized}`);
  }
  return normalized;
}

export function resolveStableCandidateQualificationCandidate({ eventName, inputCandidateSha = "", selfDogfoodEvidence } = {}) {
  if (text(eventName) === "workflow_dispatch") {
    return optionalSha(inputCandidateSha, "candidate SHA");
  }
  if (text(eventName) !== "workflow_run") {
    throw new Error(`qualification candidate resolver does not admit event ${eventName || "<empty>"}`);
  }
  const evidence = selfDogfoodEvidence;
  if (
    evidence?.contract !== "kungfu-buildchain-alpha-self-dogfood"
    || evidence?.status !== "passed"
    || evidence?.observed?.alpha?.ref !== "v4-alpha"
  ) {
    throw new Error("self-dogfood evidence is not a passing v4-alpha observation");
  }
  const observedSha = optionalSha(evidence.observed.alpha.sha, "observed v4-alpha SHA");
  const expectedSha = optionalSha(evidence.observed.alpha.expectedSha, "expected v4-alpha SHA");
  if (!observedSha || observedSha !== expectedSha) {
    throw new Error("self-dogfood evidence does not bind observed and expected v4-alpha SHAs");
  }
  return observedSha;
}

function optionalRef(value, label) {
  const normalized = text(value);
  if (
    normalized &&
    (!/^[A-Za-z0-9._/-]+$/.test(normalized) || normalized.includes("..") || normalized.startsWith("/") || normalized.endsWith("/"))
  ) {
    throw new Error(`${label} must be a safe branch or tag ref, got ${normalized}`);
  }
  return normalized;
}

export function normalizeStableCandidateQualificationOptions(options = {}) {
  const candidateSha = text(options.candidateSha ?? process.env.BUILDCHAIN_QUALIFICATION_CANDIDATE_SHA);
  if (!/^[0-9a-f]{40}$/i.test(candidateSha)) {
    throw new Error(`candidate SHA must be 40 hexadecimal characters, got ${candidateSha || "<empty>"}`);
  }
  const canaryRef = optionalRef(options.canaryRef ?? process.env.BUILDCHAIN_QUALIFICATION_CANARY_REF, "canary ref");
  const canarySha = optionalSha(options.canarySha ?? process.env.BUILDCHAIN_QUALIFICATION_CANARY_SHA, "canary SHA");
  if (Boolean(canaryRef) !== Boolean(canarySha)) {
    throw new Error("canary ref and canary SHA must be provided together");
  }
  return {
    repository: repository(options.repository ?? process.env.BUILDCHAIN_QUALIFICATION_REPOSITORY ?? process.env.GITHUB_REPOSITORY),
    candidateSha,
    buildWorkflowFile: text(options.buildWorkflowFile ?? process.env.BUILDCHAIN_QUALIFICATION_BUILD_WORKFLOW_FILE) || DEFAULTS.buildWorkflowFile,
    buildWorkflowName: text(options.buildWorkflowName ?? process.env.BUILDCHAIN_QUALIFICATION_BUILD_WORKFLOW_NAME) || DEFAULTS.buildWorkflowName,
    canaryRepository: repository(options.canaryRepository ?? process.env.BUILDCHAIN_QUALIFICATION_CANARY_REPOSITORY ?? DEFAULTS.canaryRepository),
    canaryWorkflowFile: text(options.canaryWorkflowFile ?? process.env.BUILDCHAIN_QUALIFICATION_CANARY_WORKFLOW_FILE) || DEFAULTS.canaryWorkflowFile,
    canaryWorkflowName: text(options.canaryWorkflowName ?? process.env.BUILDCHAIN_QUALIFICATION_CANARY_WORKFLOW_NAME) || DEFAULTS.canaryWorkflowName,
    canaryStatusContext: text(options.canaryStatusContext ?? process.env.BUILDCHAIN_QUALIFICATION_CANARY_STATUS_CONTEXT) || DEFAULTS.canaryStatusContext,
    canaryRef,
    canarySha,
    pollAttempts: integer(options.pollAttempts ?? process.env.BUILDCHAIN_QUALIFICATION_POLL_ATTEMPTS, DEFAULTS.pollAttempts),
    pollIntervalMs: integer(options.pollIntervalMs ?? process.env.BUILDCHAIN_QUALIFICATION_POLL_INTERVAL_MS, DEFAULTS.pollIntervalMs),
    dryRun: bool(options.dryRun ?? process.env.BUILDCHAIN_QUALIFICATION_DRY_RUN, false),
  };
}

function successful(run) {
  return run?.status === "completed" && run?.conclusion === "success";
}

function active(run) {
  return run && run.status !== "completed";
}

async function ensureWorkflowEvidence({ client, repository, workflowFile, workflowName, ref, headSha, runName, sourceSha = "", options }) {
  let run = await client.findWorkflowRun({ repository, workflowFile, workflowName, headSha, runName, sourceSha });
  if (successful(run)) return { state: "existing", run };

  let notBefore = "";
  let excludeRunId = "";
  if (!active(run)) {
    if (options.dryRun) return { state: "planned", run };
    notBefore = text(run?.created_at);
    excludeRunId = text(run?.id);
    await client.dispatchWorkflow({ repository, workflowFile, ref, inputs: runName ? { buildchain_ref: headSha } : {} });
  }

  if (options.dryRun) return { state: "waiting", run };
  run = await client.waitForWorkflowRun({
    repository,
    workflowFile,
    workflowName,
    headSha,
    runName,
    sourceSha,
    notBefore,
    excludeRunId,
    attempts: options.pollAttempts,
    intervalMs: options.pollIntervalMs,
  });
  if (!successful(run)) {
    throw new Error(`${repository} ${workflowName} did not succeed for ${headSha}: ${run?.conclusion || run?.status || "not-found"}`);
  }
  return { state: "produced", run };
}

export async function runStableCandidateQualification(optionsInput = {}, clientInput) {
  const options = normalizeStableCandidateQualificationOptions(optionsInput);
  const client = clientInput || createGitHubQualificationClient({ token: process.env.GITHUB_TOKEN });
  const candidate = await client.resolveExactAlpha(options.repository, options.candidateSha);
  if (!candidate) {
    return { schemaVersion: 1, contract: "kungfu-buildchain-stable-candidate-qualification", status: "skipped", reason: "exact-alpha-release-not-found", candidateSha: options.candidateSha };
  }

  const build = await ensureWorkflowEvidence({
    client,
    repository: options.repository,
    workflowFile: options.buildWorkflowFile,
    workflowName: options.buildWorkflowName,
    ref: candidate.tag,
    headSha: options.candidateSha,
    runName: "",
    options,
  });

  let status = await client.findCommitStatus(options.repository, options.candidateSha, options.canaryStatusContext);
  let canary = { state: status?.state === "success" ? "existing" : "pending", run: undefined };
  if (status?.state !== "success") {
    const canaryRef = options.canaryRef || await client.defaultBranch(options.canaryRepository);
    if (options.canaryRef) {
      const resolvedCanarySha = await client.resolveCommitSha(options.canaryRepository, canaryRef);
      if (resolvedCanarySha !== options.canarySha) {
        throw new Error(`canary ref ${canaryRef} resolved to ${resolvedCanarySha || "<missing>"}, expected ${options.canarySha}`);
      }
    }
    canary = await ensureWorkflowEvidence({
      client,
      repository: options.canaryRepository,
      workflowFile: options.canaryWorkflowFile,
      workflowName: options.canaryWorkflowName,
      ref: canaryRef,
      headSha: options.candidateSha,
      runName: `${options.canaryWorkflowName} / ${options.candidateSha}`,
      sourceSha: options.canarySha,
      options,
    });
    if (!options.dryRun) {
      status = await client.createCommitStatus({
        repository: options.repository,
        sha: options.candidateSha,
        context: options.canaryStatusContext,
        targetUrl: canary.run.html_url,
        description: `No-apply ${options.canaryRepository} canary passed`,
      });
    }
  }

  return {
    schemaVersion: 1,
    contract: "kungfu-buildchain-stable-candidate-qualification",
    status: options.dryRun ? "planned" : "qualified-evidence-ready",
    dryRun: options.dryRun,
    candidate,
    build: { state: build.state, url: build.run?.html_url || "" },
    canary: {
      state: canary.state,
      ref: options.canaryRef || "default-branch",
      sha: options.canarySha,
      url: canary.run?.html_url || status?.target_url || "",
    },
    attestation: { context: options.canaryStatusContext, state: options.dryRun ? "planned" : status?.state || "" },
  };
}

export function createGitHubQualificationClient({
  token,
  attestationToken = process.env.BUILDCHAIN_QUALIFICATION_ATTESTATION_TOKEN || token,
  fetchImpl = globalThis.fetch,
  sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
}) {
  const headersFor = (requestToken) => ({
    accept: "application/vnd.github+json",
    authorization: requestToken ? `Bearer ${requestToken}` : undefined,
    "user-agent": "buildchain-stable-candidate-qualification",
    "x-github-api-version": "2022-11-28",
  });
  async function api(requestPath, { method = "GET", body, requestToken = token } = {}) {
    const response = await fetchImpl(`https://api.github.com${requestPath}`, {
      method,
      headers: Object.fromEntries(Object.entries(headersFor(requestToken)).filter(([, value]) => value)),
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const raw = await response.text();
    const payload = raw ? JSON.parse(raw) : undefined;
    if (!response.ok) throw new Error(`GitHub API ${method} ${requestPath} failed with ${response.status}: ${payload?.message || raw}`);
    return payload;
  }
  const encodeRef = (ref) => ref.split("/").map(encodeURIComponent).join("/");
  async function resolveTagSha(repositoryName, tag) {
    const ref = await api(`/repos/${repositoryName}/git/ref/tags/${encodeRef(tag)}`);
    if (ref.object?.type !== "tag") return ref.object?.sha || "";
    const annotated = await api(`/repos/${repositoryName}/git/tags/${ref.object.sha}`);
    return annotated.object?.sha || "";
  }
  async function matchingRun(query) {
    const payload = await api(`/repos/${query.repository}/actions/workflows/${encodeURIComponent(query.workflowFile)}/runs?per_page=100`);
    return (payload.workflow_runs || [])
      .filter((run) => (
        (
          (!query.runName && (!query.headSha || run.head_sha === query.headSha))
          || (query.runName && (run.display_title === query.runName || run.name === query.runName))
        )
        && (!query.sourceSha || run.head_sha === query.sourceSha)
        && (!query.notBefore || String(run.created_at || "") >= query.notBefore)
        && (!query.excludeRunId || String(run.id || "") !== query.excludeRunId)
      ))
      .sort((left, right) => String(right.created_at).localeCompare(String(left.created_at)))[0];
  }
  return {
    async resolveExactAlpha(repositoryName, candidateSha) {
      const releases = await api(`/repos/${repositoryName}/releases?per_page=100`);
      for (const release of releases) {
        if (!release.prerelease || !/^v\d+\.\d+\.\d+-alpha\.\d+$/.test(release.tag_name || "")) continue;
        const sha = await resolveTagSha(repositoryName, release.tag_name);
        if (sha === candidateSha) return { version: release.tag_name.slice(1), tag: release.tag_name, sha, releaseUrl: release.html_url };
      }
      return undefined;
    },
    async defaultBranch(repositoryName) {
      return (await api(`/repos/${repositoryName}`)).default_branch;
    },
    async resolveCommitSha(repositoryName, ref) {
      return (await api(`/repos/${repositoryName}/commits/${encodeURIComponent(ref)}`)).sha || "";
    },
    findWorkflowRun: matchingRun,
    async dispatchWorkflow({ repository: repositoryName, workflowFile, ref, inputs }) {
      await api(`/repos/${repositoryName}/actions/workflows/${encodeURIComponent(workflowFile)}/dispatches`, { method: "POST", body: { ref, inputs } });
    },
    async waitForWorkflowRun(query) {
      let latest;
      for (let attempt = 0; attempt < query.attempts; attempt += 1) {
        latest = await matchingRun(query);
        if (latest?.status === "completed") return latest;
        await sleep(query.intervalMs);
      }
      return latest;
    },
    async findCommitStatus(repositoryName, sha, context) {
      const statuses = await api(`/repos/${repositoryName}/commits/${sha}/statuses?per_page=100`);
      return statuses.find((entry) => entry.context === context);
    },
    async createCommitStatus({ repository: repositoryName, sha, context, targetUrl, description }) {
      return api(`/repos/${repositoryName}/statuses/${sha}`, {
        method: "POST",
        requestToken: attestationToken,
        body: { state: "success", context, target_url: targetUrl, description },
      });
    },
  };
}

async function main() {
  if (bool(process.env.BUILDCHAIN_QUALIFICATION_RESOLVE_CANDIDATE, false)) {
    let selfDogfoodEvidence;
    if (text(process.env.BUILDCHAIN_QUALIFICATION_EVENT_NAME) === "workflow_run") {
      const fs = await import("node:fs");
      const evidencePath = text(process.env.BUILDCHAIN_QUALIFICATION_SELF_DOGFOOD_EVIDENCE);
      selfDogfoodEvidence = JSON.parse(fs.readFileSync(evidencePath, "utf8"));
    }
    const sha = resolveStableCandidateQualificationCandidate({
      eventName: process.env.BUILDCHAIN_QUALIFICATION_EVENT_NAME,
      inputCandidateSha: process.env.BUILDCHAIN_QUALIFICATION_INPUT_CANDIDATE_SHA,
      selfDogfoodEvidence,
    });
    process.stdout.write(`${sha}\n`);
    if (process.env.GITHUB_OUTPUT) {
      const fs = await import("node:fs");
      fs.appendFileSync(process.env.GITHUB_OUTPUT, `sha=${sha}\n`);
    }
    return;
  }
  const result = await runStableCandidateQualification();
  const output = `${JSON.stringify(result, null, 2)}\n`;
  process.stdout.write(output);
  if (process.env.GITHUB_STEP_SUMMARY) {
    const fs = await import("node:fs");
    fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, `## Stable candidate qualification\n\n\`\`\`json\n${output}\`\`\`\n`);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error(error.stack || error.message);
    process.exit(1);
  });
}
