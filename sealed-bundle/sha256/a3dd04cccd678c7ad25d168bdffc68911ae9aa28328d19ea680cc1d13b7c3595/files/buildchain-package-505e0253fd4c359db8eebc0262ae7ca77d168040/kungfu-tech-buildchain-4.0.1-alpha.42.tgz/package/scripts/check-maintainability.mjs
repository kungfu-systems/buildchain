#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import {
  analyzeSource,
  analyzeWorkflow,
  collectMaintainabilityMetrics,
  isHandMaintainedSource,
} from "./maintainability-metrics.mjs";
import {
  calculateDebtMeasuredExcess,
  evaluateDebtAuthority,
  evaluateDebtBudget,
  evaluateExceptionBudget,
  evaluateExceptionGovernance,
  evaluateTestBudgets,
  evaluateWorkflowBudgets,
} from "./maintainability-governance.mjs";

function collectHotspots(root, current, limit = 20, shallowFallback = []) {
  const maintained = new Set([
    ...Object.keys(current.files || {}),
    ...Object.keys(current.tests || {}),
    ...Object.keys(current.workflows || {}),
  ]);
  // Shallow consumers cannot reproduce repository-wide churn ranking.
  // Reuse the audited routes; full clones still re-rank them below.
  // This keeps consumer verification deterministic without inventing history.
  if (
    gitOutput(root, ["rev-parse", "--is-shallow-repository"]).trim() === "true"
  ) {
    return shallowFallback.slice(0, limit);
  }
  const counts = new Map();
  const record = (file) =>
    maintained.has(file) && counts.set(file, (counts.get(file) || 0) + 1);
  for (const args of [
    ["log", "-n", "500", "--format=", "--name-only"],
    ["diff", "--name-only"],
  ])
    for (const file of gitOutput(root, args).split("\n").filter(Boolean))
      record(file);
  return [...counts]
    .sort(
      ([leftPath, left], [rightPath, right]) =>
        right - left || leftPath.localeCompare(rightPath),
    )
    .slice(0, limit)
    .map(([file]) => file);
}

function readJson(root, file) {
  return JSON.parse(fs.readFileSync(path.join(root, file), "utf8"));
}

function gitOutput(root, args) {
  return execFileSync("git", args, { cwd: root, encoding: "utf8" });
}

function revisionAvailable(root, revision) {
  try {
    execFileSync("git", ["cat-file", "-e", `${revision}^{commit}`], {
      cwd: root,
      stdio: "ignore",
    });
    return true;
  } catch {
    return false;
  }
}

function ensureRevisionAvailable(root, revision) {
  if (revisionAvailable(root, revision)) return false;
  try {
    gitOutput(root, ["fetch", "--no-tags", "--depth=1", "origin", revision]);
  } catch (error) {
    const detail = String(error?.stderr || error?.message || error).trim();
    throw new Error(
      `maintainability revision ${revision} is unavailable and could not be fetched from origin${detail ? `: ${detail}` : ""}`,
    );
  }
  if (!revisionAvailable(root, revision)) {
    throw new Error(
      `maintainability revision ${revision} is unavailable after a successful origin fetch`,
    );
  }
  return true;
}

function ensureMaintainabilityRevisionsAvailable(
  root,
  { baselineRevision, enforcementRevision },
) {
  return Object.fromEntries(
    [...new Set([baselineRevision, enforcementRevision])].map((revision) => [
      revision,
      ensureRevisionAvailable(root, revision),
    ]),
  );
}

function sourceMetricsAtRevision(root, revision) {
  const files = gitOutput(root, ["ls-tree", "-r", "--name-only", revision])
    .split("\n")
    .filter(isHandMaintainedSource)
    .sort();
  return Object.fromEntries(
    files.map((file) => [
      file,
      analyzeSource(file, gitOutput(root, ["show", `${revision}:${file}`])),
    ]),
  );
}

function testMetricsAtRevision(root, revision) {
  const files = gitOutput(root, ["ls-tree", "-r", "--name-only", revision])
    .split("\n")
    .filter((file) =>
      /(?:^tests\/|(?:^|\/)tests?\/).+\.(?:c|m)?js$/u.test(file),
    )
    .sort();
  return Object.fromEntries(
    files.map((file) => [
      file,
      analyzeSource(file, gitOutput(root, ["show", `${revision}:${file}`])),
    ]),
  );
}

function workflowMetricsAtRevision(root, revision) {
  const files = gitOutput(root, ["ls-tree", "-r", "--name-only", revision])
    .split("\n")
    .filter((file) => /^\.github\/workflows\/.*\.ya?ml$/u.test(file))
    .sort();
  return Object.fromEntries(
    files.map((file) => [
      file,
      analyzeWorkflow(file, gitOutput(root, ["show", `${revision}:${file}`])),
    ]),
  );
}

function maximumFunction(metrics, field) {
  return Math.max(
    0,
    ...(metrics?.functions || []).map((entry) => entry[field]),
  );
}

function selectedFunction(metrics, file, name) {
  return metrics.files[file]?.functions.find((entry) => entry.name === name);
}

function readJsonAtRevision(root, revision, file) {
  return JSON.parse(gitOutput(root, ["show", `${revision}:${file}`]));
}

function publicSurfaceContract(entry, kind) {
  if (kind === "cli") return { id: entry.id, usage: entry.usage };
  if (kind === "node")
    return {
      export: entry.export,
      specifier: entry.specifier,
      target: entry.target,
    };
  return {
    id: entry.id,
    path: entry.path,
    reusable: entry.reusable,
    inputs: entry.inputs || [],
    secrets: entry.secrets || [],
    outputs: entry.outputs || [],
  };
}

function evaluatePublicSurface({ root, revision, policy }) {
  const issues = [];
  const lifecycleFields = policy.publicSurfacePolicy.requiredLifecycleFields;
  const capabilityGroups = new Set(
    readJson(root, "dist/site/capability-registry.json").groups.map(
      (entry) => entry.id,
    ),
  );
  const definitions = [
    {
      file: "dist/site/cli-registry.json",
      collection: "commands",
      kind: "cli",
      key: "id",
    },
    {
      file: "dist/site/node-api-registry.json",
      collection: "exports",
      kind: "node",
      key: "export",
    },
    {
      file: "dist/site/workflow-registry.json",
      collection: "workflows",
      kind: "workflow",
      key: "id",
    },
    {
      file: "dist/site/workflow-registry.json",
      collection: "actions",
      kind: "action",
      key: "id",
    },
  ];
  for (const definition of definitions) {
    const current =
      readJson(root, definition.file)[definition.collection] || [];
    const baseline =
      readJsonAtRevision(root, revision, definition.file)[
        definition.collection
      ] || [];
    const baselineByKey = new Map(
      baseline.map((entry) => [entry[definition.key], entry]),
    );
    for (const entry of current) {
      const label = `${definition.kind}:${entry[definition.key]}`;
      for (const field of lifecycleFields) {
        if (
          !Object.prototype.hasOwnProperty.call(entry, field) ||
          typeof entry[field] !== "string"
        ) {
          issues.push(`${label}: lifecycle field ${field} is missing`);
        }
      }
      if (!capabilityGroups.has(entry.capabilityGroup)) {
        issues.push(
          `${label}: capability group ${entry.capabilityGroup || "<empty>"} is not registered`,
        );
      }
      const previous = baselineByKey.get(entry[definition.key]);
      const currentContract = publicSurfaceContract(entry, definition.kind);
      if (
        previous &&
        JSON.stringify(currentContract) !==
          JSON.stringify(publicSurfaceContract(previous, definition.kind))
      ) {
        const approval = policy.approvedPublicSurfaceTransitions?.[label];
        const approved =
          approval?.fromRevision === revision &&
          String(approval?.rationale || "").trim() &&
          JSON.stringify(approval?.contract) ===
            JSON.stringify(currentContract);
        if (!approved) {
          issues.push(
            `${label}: existing public contract drifted from ${revision}`,
          );
        }
      }
      if (!previous && !entry.nonDuplicationRationale) {
        issues.push(
          `${label}: new public surface requires a non-duplication rationale`,
        );
      }
    }
  }
  return issues;
}

function evaluateAddedFunctionBudgets({
  file,
  metrics,
  baseline,
  policy,
  budgets,
}) {
  const issues = [];
  const identity = (entry) =>
    entry.name.startsWith("<anonymous@") ? "<anonymous>" : entry.name;
  const baselineFunctionCounts = new Map();
  for (const entry of baseline.functions || []) {
    const key = identity(entry);
    baselineFunctionCounts.set(key, (baselineFunctionCounts.get(key) || 0) + 1);
  }
  const currentFunctionCounts = new Map();
  for (const entry of metrics.functions) {
    const identityKey = identity(entry);
    const occurrence = (currentFunctionCounts.get(identityKey) || 0) + 1;
    currentFunctionCounts.set(identityKey, occurrence);
    if (occurrence <= (baselineFunctionCounts.get(identityKey) || 0)) {
      continue;
    }
    const key = `${file}#${entry.name}`;
    const approval = policy.approvedExtractedDebt?.[key];
    if (approval && !String(approval.rationale || "").trim()) {
      issues.push(`${key}: approved extracted debt requires a rationale`);
    }
    const allowedLines = approval?.maxLines ?? budgets.newFunctionLines;
    const allowedComplexity =
      approval?.maxComplexity ?? budgets.newFunctionComplexity;
    if (entry.lines > allowedLines) {
      issues.push(
        `${file}:${entry.start} ${entry.name} has ${entry.lines} lines; new-function budget is ${allowedLines}`,
      );
    }
    if (entry.complexity > allowedComplexity) {
      issues.push(
        `${file}:${entry.start} ${entry.name} has complexity ${entry.complexity}; new-function budget is ${allowedComplexity}`,
      );
    }
  }
  return issues;
}

function evaluateRepositoryBudgets({ current, policy }) {
  const issues = [];
  const budgets = policy.repositoryBudgets;
  if (!budgets) return issues;
  if (!String(budgets.rationale || "").trim()) {
    issues.push("repository growth budget requires a rationale");
  }
  const checks = [
    [
      "handMaintainedSourceFiles",
      "maxHandMaintainedSourceFiles",
      "source files",
    ],
    [
      "handMaintainedSourceLines",
      "maxHandMaintainedSourceLines",
      "source lines",
    ],
    ["workflowFiles", "maxWorkflowFiles", "workflow files"],
    ["workflowLines", "maxWorkflowLines", "workflow lines"],
  ];
  for (const [metric, ceiling, label] of checks) {
    if (!Number.isInteger(budgets[ceiling]) || budgets[ceiling] < 0) {
      issues.push(
        `repository growth budget ${ceiling} must be a non-negative integer`,
      );
      continue;
    }
    if (current.repository[metric] > budgets[ceiling]) {
      issues.push(
        `repository ${label} are ${current.repository[metric]}; approved ceiling is ${budgets[ceiling]}`,
      );
    }
  }
  return issues;
}

function budgetsForFile(policy, file) {
  return file.endsWith(".rs") ? policy.rustBudgets : policy.sourceBudgets;
}

function evaluateMaintainability({ current, baselineFiles, policy }) {
  const issues = [];
  for (const [file, metrics] of Object.entries(current.files)) {
    const budgets = budgetsForFile(policy, file);
    const baseline = baselineFiles[file];
    if (!baseline) {
      const transition = policy.approvedNewFileTransitions?.[file];
      if (transition && !String(transition.rationale || "").trim()) {
        issues.push(
          `${file}: approved new-file transition requires a rationale`,
        );
      }
      const allowedFileLines = transition?.maxLines ?? budgets.newFileLines;
      if (metrics.lines > allowedFileLines) {
        issues.push(
          `${file}: new file has ${metrics.lines} lines; budget is ${allowedFileLines}`,
        );
      }
      for (const entry of metrics.functions) {
        const key = `${file}#${entry.name}`;
        const approval = policy.approvedExtractedDebt?.[key];
        if (approval && !String(approval.rationale || "").trim()) {
          issues.push(`${key}: approved extracted debt requires a rationale`);
        }
        const allowedLines = approval?.maxLines ?? budgets.newFunctionLines;
        const allowedComplexity =
          approval?.maxComplexity ?? budgets.newFunctionComplexity;
        if (entry.lines > allowedLines) {
          issues.push(
            `${file}:${entry.start} ${entry.name} has ${entry.lines} lines; new-function budget is ${allowedLines}`,
          );
        }
        if (entry.complexity > allowedComplexity) {
          issues.push(
            `${file}:${entry.start} ${entry.name} has complexity ${entry.complexity}; new-function budget is ${allowedComplexity}`,
          );
        }
      }
      continue;
    }
    const transition = policy.approvedExistingDebtTransitions?.[file];
    if (transition && !String(transition.rationale || "").trim()) {
      issues.push(`${file}: approved debt transition requires a rationale`);
    }
    const allowedLines =
      transition?.maxLines ?? Math.max(baseline.lines, budgets.newFileLines);
    const allowedFunctionLines =
      transition?.maxFunctionLines ??
      Math.max(maximumFunction(baseline, "lines"), budgets.newFunctionLines);
    const allowedFunctionComplexity =
      transition?.maxFunctionComplexity ??
      Math.max(
        maximumFunction(baseline, "complexity"),
        budgets.newFunctionComplexity,
      );
    if (metrics.lines > allowedLines) {
      issues.push(
        `${file}: file debt widened from ${baseline.lines} to ${metrics.lines} lines`,
      );
    }
    const maxLines = maximumFunction(metrics, "lines");
    if (maxLines > allowedFunctionLines) {
      issues.push(
        `${file}: maximum function length widened beyond ${allowedFunctionLines} to ${maxLines}`,
      );
    }
    const maxComplexity = maximumFunction(metrics, "complexity");
    if (maxComplexity > allowedFunctionComplexity) {
      issues.push(
        `${file}: maximum function complexity widened beyond ${allowedFunctionComplexity} to ${maxComplexity}`,
      );
    }
    issues.push(
      ...evaluateAddedFunctionBudgets({
        file,
        metrics,
        baseline,
        policy,
        budgets,
      }),
    );
  }

  for (const [name, budget] of Object.entries(policy.selectedFunctionBudgets)) {
    const entry = selectedFunction(current, budget.file, name);
    if (!entry) {
      issues.push(`${budget.file}: selected function ${name} is missing`);
      continue;
    }
    if (entry.lines > budget.lines) {
      issues.push(
        `${budget.file}: ${name} has ${entry.lines} lines; terminal budget is ${budget.lines}`,
      );
    }
    if (entry.complexity > budget.complexity) {
      issues.push(
        `${budget.file}: ${name} has complexity ${entry.complexity}; terminal budget is ${budget.complexity}`,
      );
    }
  }
  return issues;
}

function checkMaintainability({ root = process.cwd() } = {}) {
  const policy = readJson(root, "architecture/maintainability-policy.json");
  if (policy.schemaVersion !== 2) {
    throw new Error("maintainability policy schemaVersion must be 2");
  }
  const baseline = readJson(root, policy.baseline);
  const enforcementRevision = policy.enforcementRevision || baseline.revision;
  const extendedCoverageRevision =
    policy.extendedCoverageRevision || enforcementRevision;
  const hydratedRevisions = ensureMaintainabilityRevisionsAvailable(root, {
    baselineRevision: baseline.revision,
    enforcementRevision,
  });
  const hydratedExtendedCoverageRevision = ensureRevisionAvailable(
    root,
    extendedCoverageRevision,
  );
  const current = collectMaintainabilityMetrics({ root });
  const debt = readJson(root, "architecture/maintainability-debt.json");
  const architecture = readJson(
    root,
    "architecture/internal-capabilities.json",
  );
  const baselineFiles = sourceMetricsAtRevision(root, enforcementRevision);
  const extendedSourceFiles = sourceMetricsAtRevision(
    root,
    extendedCoverageRevision,
  );
  for (const [file, metrics] of Object.entries(extendedSourceFiles)) {
    if (file.endsWith(".rs")) baselineFiles[file] = metrics;
  }
  const baselineTests = testMetricsAtRevision(root, extendedCoverageRevision);
  const baselineWorkflows = workflowMetricsAtRevision(
    root,
    extendedCoverageRevision,
  );
  const issues = evaluateExceptionGovernance({ policy });
  issues.push(...evaluateExceptionBudget({ policy }));
  const hotspots = collectHotspots(root, current, 20, debt.hotspots || []);
  issues.push(
    ...evaluateDebtAuthority({
      current,
      policy,
      debt,
      capabilityIds: new Set(
        architecture.capabilities.map((entry) => entry.id),
      ),
      hotspots,
    }),
  );
  issues.push(...evaluateDebtBudget({ debt, policy }));
  issues.push(...evaluateMaintainability({ current, baselineFiles, policy }));
  issues.push(
    ...evaluateTestBudgets({ current, baselineFiles: baselineTests, policy }),
  );
  issues.push(
    ...evaluateWorkflowBudgets({
      current,
      baselineFiles: baselineWorkflows,
      policy,
    }),
  );
  issues.push(...evaluateRepositoryBudgets({ current, policy }));
  issues.push(
    ...evaluatePublicSurface({ root, revision: enforcementRevision, policy }),
  );
  if (issues.length > 0) {
    throw new Error(`maintainability check failed:\n- ${issues.join("\n- ")}`);
  }
  return {
    schemaVersion: 1,
    baselineRevision: baseline.revision,
    enforcementRevision,
    extendedCoverageRevision,
    hydratedBaselineRevision: hydratedRevisions[baseline.revision],
    hydratedEnforcementRevision: hydratedRevisions[enforcementRevision],
    hydratedExtendedCoverageRevision,
    trackedFiles: current.repository.trackedFiles,
    sourceFiles: current.repository.handMaintainedSourceFiles,
    publicSurface: current.publicSurface,
    hotspots: current.hotspots,
    governedDebtSurfaces: Object.values(debt.surfaces).reduce(
      (total, entries) => total + Object.keys(entries).length,
      0,
    ),
  };
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href
) {
  try {
    const report = checkMaintainability();
    console.log(
      `maintainability check passed: ${report.sourceFiles} source files against ${report.enforcementRevision} ` +
        `(audit baseline ${report.baselineRevision})`,
    );
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  }
}

export {
  calculateDebtMeasuredExcess,
  checkMaintainability,
  collectHotspots,
  ensureMaintainabilityRevisionsAvailable,
  ensureRevisionAvailable,
  evaluateMaintainability,
  evaluateDebtAuthority,
  evaluateDebtBudget,
  evaluateExceptionBudget,
  evaluateExceptionGovernance,
  evaluateRepositoryBudgets,
  evaluateTestBudgets,
  evaluateWorkflowBudgets,
  evaluatePublicSurface,
  sourceMetricsAtRevision,
  testMetricsAtRevision,
  workflowMetricsAtRevision,
};
