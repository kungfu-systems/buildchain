#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourcePath = path.join(root, ".github/workflows/.release-candidate-promote.yml");
const targetPath = path.join(root, ".github/workflows/release-candidate-promote.yml");
const routingPath = path.join(root, ".buildchain/promotion-shell-routing.json");
const internalInputs = new Set([
  "promotion-router-ref",
  "promotion-router-sha",
  "promotion-shell-ref",
  "promotion-shell-sha",
  "promotion-runtime-ref",
  "promotion-runtime-sha",
  "promotion-contract-lock-path",
  "promotion-contract-lock-digest",
  "promotion-publication-channel",
  "promotion-target-ref",
  "promotion-override-used",
  "promotion-runtime-authorization-json",
  "promotion-runtime-authorization-root",
  "publication-authority-workflow-path",
  "buildchain-expected-channel",
  "buildchain-expected-major",
  "buildchain-alpha-contract-lock-path",
  "buildchain-stable-contract-lock-path",
]);

function blockBetween(source, start, end) {
  const startIndex = source.indexOf(start);
  const endIndex = source.indexOf(end, startIndex + start.length);
  if (startIndex < 0 || endIndex < 0) throw new Error(`unable to locate workflow block: ${start.trim()}`);
  return source.slice(startIndex + start.length, endIndex);
}

function entries(block, indent = 6) {
  const pattern = new RegExp(`^ {${indent}}([a-z0-9-]+):$`, "gm");
  const matches = [...block.matchAll(pattern)];
  return matches.map((match, index) => ({
    name: match[1],
    source: block.slice(match.index, matches[index + 1]?.index ?? block.length).trimEnd(),
  }));
}

function publicInputs(inputBlock) {
  const retained = entries(inputBlock)
    .filter((entry) => !internalInputs.has(entry.name))
    .map((entry) => entry.name === "buildchain-contract-lock-path"
      ? entry.source.replace('        default: ".buildchain/contract-lock.json"', '        default: ""')
      : entry.source);
  return [
    "      buildchain-channel:",
    '        description: "Promotion workflow-shell/runtime channel: auto, alpha, or stable"',
    '        default: "auto"',
    "        type: string",
    "        required: false",
    "      buildchain-alpha-contract-lock-path:",
    '        description: "Consumer-owned contract lock selected for alpha promotion"',
    '        default: ".buildchain/alpha-contract-lock.json"',
    "        type: string",
    "        required: false",
    "      buildchain-stable-contract-lock-path:",
    '        description: "Consumer-owned contract lock selected for stable promotion"',
    '        default: ".buildchain/contract-lock.json"',
    "        type: string",
    "        required: false",
    ...retained,
  ].join("\n");
}

function publicOutputs(outputBlock) {
  const forwarded = entries(outputBlock).map((entry) => entry.source.replace(
    /^        value:.*$/m,
    `        value: \${{ jobs.invoke.outputs.${entry.name} }}`,
  ));
  const routed = [
    ["buildchain-channel", "Selected promotion workflow-shell channel", "channel"],
    ["promotion-router-ref", "Router workflow ref", "router-ref"],
    ["promotion-router-sha", "Resolved router workflow SHA", "router-sha"],
    ["promotion-shell-ref", "Selected advanced promotion workflow-shell ref", "shell-ref"],
    ["promotion-shell-sha", "Resolved advanced promotion workflow-shell SHA", "shell-sha"],
    ["promotion-runtime-ref", "Selected Buildchain runtime ref", "runtime-ref"],
    ["promotion-runtime-sha", "Resolved Buildchain runtime SHA", "runtime-sha"],
    ["promotion-contract-lock-path", "Selected consumer contract-lock path", "contract-lock-path"],
    ["promotion-contract-lock-digest", "Selected consumer contract-lock sha256 digest", "contract-lock-digest"],
    ["promotion-publication-channel", "Derived publication channel", "publication-channel"],
    ["promotion-target-ref", "Derived promotion target ref", "target-ref"],
    ["promotion-override-used", "Whether a trusted runtime override was used", "override-used"],
  ].map(([name, description, output]) => [
    `      ${name}:`,
    `        description: "${description}"`,
    `        value: \${{ jobs.resolve-promotion.outputs.${output} }}`,
  ].join("\n"));
  return [...routed, ...forwarded].join("\n");
}

function forwardedInputs(inputNames, { includeInternal = true, major = 2, unsupportedInputs = [], workflowPath = ".github/workflows/.release-candidate-promote.yml" } = {}) {
  const unsupported = new Set(unsupportedInputs);
  return inputNames
    .filter((name) => includeInternal || !internalInputs.has(name))
    .filter((name) => !unsupported.has(name))
    .map((name) => {
      const routed = {
        "buildchain-ref": "runtime-sha",
        "buildchain-contract-lock-path": "contract-lock-path",
        "buildchain-expected-channel": "channel",
        channel: "publication-channel",
        "target-ref": "target-ref",
        "promotion-router-ref": "router-ref",
        "promotion-router-sha": "router-sha",
        "promotion-shell-ref": "shell-call-ref",
        "promotion-shell-sha": "shell-sha",
        "promotion-runtime-ref": "runtime-ref",
        "promotion-runtime-sha": "runtime-sha",
        "promotion-contract-lock-path": "contract-lock-path",
        "promotion-contract-lock-digest": "contract-lock-digest",
        "promotion-publication-channel": "publication-channel",
        "promotion-target-ref": "target-ref",
        "promotion-override-used": "override-used",
      }[name];
      if (name === "promotion-override-used") {
        return `      ${name}: \${{ needs.resolve-promotion.outputs.override-used == 'true' }}`;
      }
      if (name === "promotion-runtime-authorization-json") {
        return `      ${name}: \${{ needs.consumer-admission.outputs.runtime-authorization-json }}`;
      }
      if (name === "promotion-runtime-authorization-root") {
        return `      ${name}: \${{ needs.consumer-admission.outputs.runtime-authorization-root }}`;
      }
      if (name === "buildchain-expected-major") {
        return `      buildchain-expected-major: "${major}"`;
      }
      if (name === "publication-authority-workflow-path") {
        return `      publication-authority-workflow-path: ${workflowPath}`;
      }
      return routed
        ? `      ${name}: \${{ needs.resolve-promotion.outputs.${routed} }}`
        : `      ${name}: \${{ inputs.${name} }}`;
    }).join("\n");
}

function routedInputs(inputNames, route, major) {
  return forwardedInputs(inputNames, {
    includeInternal: route.forwardInternalInputs,
    major,
    unsupportedInputs: route.unsupportedInputs,
    workflowPath: route.workflowPath,
  });
}

function validateWorkflowRoute(name, route, expectedLogicalRef) {
  if (!route || typeof route !== "object") throw new Error(`promotion shell routing missing ${name} route`);
  if (route.logicalRef !== expectedLogicalRef) {
    throw new Error(`promotion shell ${name} logicalRef must be ${expectedLogicalRef}`);
  }
  if (!/^\.github\/workflows\/[.a-z0-9-]+\.ya?ml$/.test(route.workflowPath || "")) {
    throw new Error(`promotion shell ${name} workflowPath must name a reusable workflow`);
  }
  if (!/^(?:v[0-9]+(?:-alpha)?|(?:train|alpha|release)\/[A-Za-z0-9._+\/-]+|[0-9a-f]{40})$/.test(route.callRef || "")) {
    throw new Error(`promotion shell ${name} callRef must be an official tag, protected channel ref, trusted train, or exact SHA`);
  }
  if (typeof route.forwardInternalInputs !== "boolean") {
    throw new Error(`promotion shell ${name} forwardInternalInputs must be boolean`);
  }
  const unsupportedInputs = route.unsupportedInputs ?? [];
  if (
    !Array.isArray(unsupportedInputs) ||
    unsupportedInputs.some((input) => !/^[a-z0-9-]+$/.test(input)) ||
    new Set(unsupportedInputs).size !== unsupportedInputs.length
  ) {
    throw new Error(`promotion shell ${name} unsupportedInputs must contain unique workflow input names`);
  }
  return { ...route, unsupportedInputs };
}

export function parsePromotionShellRouting(source, { major = 2 } = {}) {
  const parsed = JSON.parse(source);
  if (parsed.schemaVersion !== 1) throw new Error("promotion shell routing schemaVersion must be 1");
  if (parsed.major !== major) throw new Error(`promotion shell routing major must be ${major}`);
  return {
    alpha: validateWorkflowRoute("alpha", parsed.alpha, `v${major}-alpha`),
    stable: validateWorkflowRoute("stable", parsed.stable, `v${major}`),
  };
}

function consumerAdmissionJob() {
  return `  consumer-admission:
    name: Admit v4 floating consumer policy
    needs: resolve-promotion
    runs-on: ubuntu-24.04
    permissions:
      contents: read
    outputs:
      runtime-authorization-json: \${{ steps.runtime-authority.outputs.runtime-authorization-json }}
      runtime-authorization-root: \${{ steps.runtime-authority.outputs.runtime-authorization-root }}
    steps:
      - name: Checkout exact consumer source
        uses: actions/checkout@v7.0.0
        with:
          ref: \${{ inputs.target-sha || github.sha }}
          path: .buildchain/consumer
          persist-credentials: false
      - name: Checkout exact policy runtime
        uses: actions/checkout@v7.0.0
        with:
          repository: \${{ inputs.buildchain-repository }}
          ref: \${{ needs.resolve-promotion.outputs.router-sha }}
          path: .buildchain/v4-policy-runtime
          persist-credentials: false
      - name: Enforce v4 floating consumer policy
        id: policy
        env:
          BUILDCHAIN_CONSUMER_ROOT: .buildchain/consumer
          BUILDCHAIN_INVOCATION_SOURCE_PATH: \${{ inputs.publication-publisher-workflow-path == '.github/workflows/buildchain-ref-promotion-recovery.yml' && '.github/workflows/release-candidate-promote.yml' || inputs.publication-publisher-workflow-path }}
          BUILDCHAIN_EXPECTED_INVOCATION_CHANNEL: \${{ needs.resolve-promotion.outputs.channel }}
          BUILDCHAIN_INVOKED_WORKFLOW: \${{ inputs.publication-publisher-workflow-path == '.github/workflows/buildchain-ref-promotion-recovery.yml' && '.github/workflows/.release-candidate-promote.yml' || '.github/workflows/release-candidate-promote.yml' }}
          BUILDCHAIN_WORKFLOW_SHA: \${{ needs.resolve-promotion.outputs.router-sha }}
          BUILDCHAIN_RUNTIME_SHA: \${{ needs.resolve-promotion.outputs.router-sha }}
          BUILDCHAIN_STABLE_CONTRACT_LOCK_PATH: \${{ inputs.buildchain-stable-contract-lock-path }}
          BUILDCHAIN_ALPHA_CONTRACT_LOCK_PATH: \${{ inputs.buildchain-alpha-contract-lock-path }}
          BUILDCHAIN_V4_POLICY_RECEIPT_PATH: .buildchain/evidence/v4-consumer-policy-receipt.json
        run: >-
          node .buildchain/v4-policy-runtime/scripts/v4-consumer-policy.mjs scan
          --source-sha "\${{ inputs.target-sha || github.sha }}"

      - name: Upload rooted consumer admission receipt
        uses: actions/upload-artifact@v7.0.1
        with:
          name: v4-consumer-policy-release-candidate-promote-\${{ github.sha }}
          path: .buildchain/consumer/.buildchain/evidence/v4-consumer-policy-receipt.json
          if-no-files-found: error

      - name: Authorize transient v4 runtime selection
        id: runtime-authority
        if: \${{ needs.resolve-promotion.outputs.override-used == 'true' }}
        uses: actions/github-script@v8
        env:
          BUILDCHAIN_RUNTIME_AUTHORIZATION_PATH: .buildchain/consumer/.buildchain/evidence/v4-runtime-authorization.json
        with:
          script: |
            const script = require(process.env.GITHUB_WORKSPACE + "/.buildchain/v4-policy-runtime/scripts/authorize-promotion-runtime-override.cjs");
            const result = await script.authorizePromotionRuntimeOverride({
              github,
              context,
              request: {
                consumerRoot: process.env.GITHUB_WORKSPACE + "/.buildchain/consumer",
                runtimeModulePath: process.env.GITHUB_WORKSPACE + "/.buildchain/v4-policy-runtime/packages/core/v4-runtime-ref-resume-authority.js",
                runtimeRepository: "\${{ inputs.buildchain-repository }}",
                consumerPolicyReceiptPath: process.env.GITHUB_WORKSPACE + "/.buildchain/consumer/.buildchain/evidence/v4-consumer-policy-receipt.json",
                consumerPolicyReceiptRoot: "\${{ steps.policy.outputs.v4-consumer-policy-receipt-root }}",
                sourceSha: "\${{ inputs.target-sha || github.sha }}",
                requestedRef: "\${{ needs.resolve-promotion.outputs.runtime-ref }}",
                resolvedRuntimeSha: "\${{ needs.resolve-promotion.outputs.runtime-sha }}",
                reason: "trusted \${{ inputs.resume-candidate-run-id != '' && 'resume' || 'dispatch' }} runtime override \${{ needs.resolve-promotion.outputs.runtime-ref }} for source \${{ inputs.target-sha || github.sha }}",
                mode: "\${{ inputs.resume-candidate-run-id != '' && 'resume' || 'dispatch' }}",
                outputPath: process.env.BUILDCHAIN_RUNTIME_AUTHORIZATION_PATH,
              },
            });
            core.setOutput("runtime-authorization-json", JSON.stringify({
              receipt: result.receipt,
              receiptRoot: result.receiptRoot,
            }));
            core.setOutput("runtime-authorization-root", result.receiptRoot);

      - name: Upload transient runtime authorization receipt
        if: \${{ needs.resolve-promotion.outputs.override-used == 'true' }}
        uses: actions/upload-artifact@v7.0.1
        with:
          name: v4-runtime-authorization-release-candidate-promote-\${{ github.run_id }}
          path: .buildchain/consumer/.buildchain/evidence/v4-runtime-authorization.json
          if-no-files-found: error
`;
}

export function generateChannelPromotionWorkflow(source, { major = 2, shellRouting } = {}) {
  const routes = shellRouting || {
    alpha: {
      logicalRef: `v${major}-alpha`,
      callRef: `v${major}-alpha`,
      workflowPath: ".github/workflows/.release-candidate-promote.yml",
      forwardInternalInputs: true,
      unsupportedInputs: [],
    },
    stable: {
      logicalRef: `v${major}`,
      callRef: `v${major}`,
      workflowPath: ".github/workflows/.release-candidate-promote.yml",
      forwardInternalInputs: true,
      unsupportedInputs: [],
    },
  };
  const alphaRoute = validateWorkflowRoute("alpha", routes.alpha, `v${major}-alpha`);
  validateWorkflowRoute("stable", routes.stable, `v${major}`);
  const inputs = blockBetween(source, "    inputs:\n", "    secrets:\n");
  const secrets = blockBetween(source, "    secrets:\n", "    outputs:\n");
  const outputs = blockBetween(source, "    outputs:\n", "\nconcurrency:\n");
  const inputNames = entries(inputs).map((entry) => entry.name);
  for (const required of ["buildchain-ref", "buildchain-contract-lock-path", "channel", "target-ref", ...internalInputs]) {
    if (!inputNames.includes(required)) throw new Error(`advanced promotion workflow missing input: ${required}`);
  }
  const invokeForwarded = routedInputs(inputNames, alphaRoute, major);
  return `# Generated by scripts/generate-channel-promotion-workflow.mjs. Do not edit directly.
name: Release Candidate Promote

on:
  workflow_call:
    inputs:
${publicInputs(inputs)}
    secrets:
${secrets.trimEnd()}
    outputs:
${publicOutputs(outputs)}

permissions:
  actions: write
  artifact-metadata: write
  attestations: write
  checks: write
  contents: write
  id-token: write
  issues: write
  pull-requests: write

jobs:
  resolve-promotion:
    name: Resolve promotion workflow shell and runtime
    runs-on: ubuntu-24.04
    permissions:
      contents: read
    outputs:
      channel: \${{ steps.route.outputs.channel }}
      publication-channel: \${{ steps.route.outputs.publication-channel }}
      target-ref: \${{ steps.route.outputs.target-ref }}
      router-ref: \${{ steps.router.outputs.ref }}
      router-sha: \${{ steps.router.outputs.sha }}
      shell-ref: \${{ steps.identities.outputs.shell-ref }}
      shell-call-ref: \${{ steps.identities.outputs.shell-call-ref }}
      shell-sha: \${{ steps.identities.outputs.shell-sha }}
      runtime-ref: \${{ steps.route.outputs.runtime-ref }}
      runtime-sha: \${{ steps.identities.outputs.runtime-sha }}
      contract-lock-path: \${{ steps.lock.outputs.path }}
      contract-lock-digest: \${{ steps.lock.outputs.digest }}
      override-used: \${{ steps.route.outputs.override-used }}
      selection-source: \${{ steps.route.outputs.selection-source }}
      reason: \${{ steps.route.outputs.reason }}
    steps:
      - name: Resolve promotion router source
        id: router
        shell: bash
        env:
          BUILDCHAIN_ROUTER_REPOSITORY: \${{ inputs.buildchain-repository }}
          BUILDCHAIN_ROUTER_REF: \${{ inputs.buildchain-ref }}
          BUILDCHAIN_RESUME_RUN_ID: \${{ inputs.resume-candidate-run-id }}
          BUILDCHAIN_RESUME_RUNTIME_SHA: \${{ inputs.resume-buildchain-runtime-sha }}
        run: |
          set -euo pipefail
          repository="\${BUILDCHAIN_ROUTER_REPOSITORY}"
          ref="\${BUILDCHAIN_ROUTER_REF}"
          ref="\${ref#refs/heads/}"
          ref="\${ref#refs/tags/}"
          if [[ ! "\${repository}" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ || -z "\${ref}" || "\${ref}" = /* || "\${ref}" = *..* ]]; then
            echo "::error::Unable to resolve promotion router source from repository/ref inputs"
            exit 1
          fi

          if [[ "\${ref}" =~ ^[0-9a-fA-F]{40}$ ]]; then sha="\${ref,,}"; else
            remote_url="https://github.com/\${repository}.git"
            refs="$(git ls-remote "\${remote_url}" "refs/heads/\${ref}" "refs/tags/\${ref}" "refs/tags/\${ref}^{}")"
            head_sha="$(printf '%s\\n' "\${refs}" | awk -v name="refs/heads/\${ref}" '$2 == name { print tolower($1) }')"
            tag_sha="$(printf '%s\\n' "\${refs}" | awk -v peeled="refs/tags/\${ref}^{}" -v name="refs/tags/\${ref}" '$2 == peeled { print tolower($1); found=1 } $2 == name && !found { fallback=tolower($1) } END { if (!found && fallback != "") print fallback }')"
            if [[ -n "\${head_sha}" && -n "\${tag_sha}" && "\${head_sha}" != "\${tag_sha}" ]]; then echo "::error::Promotion router ref is ambiguous between branch and tag"; exit 1; fi
            sha="\${head_sha:-\${tag_sha}}"
          fi
          if [[ ! "\${sha}" =~ ^[0-9a-f]{40}$ ]]; then
            echo "::error::Promotion router ref did not resolve to one exact commit SHA"
            exit 1
          fi
          if [[ -n "\${BUILDCHAIN_RESUME_RUN_ID}" ]]; then
            expected_sha="\${BUILDCHAIN_RESUME_RUNTIME_SHA,,}"
            if [[ ! "\${expected_sha}" =~ ^[0-9a-f]{40}$ || "\${sha}" != "\${expected_sha}" ]]; then
              echo "::error::Recovery router ref does not match resume-buildchain-runtime-sha"
              exit 1
            fi
          fi
          {
            echo "repository=\${repository}"
            echo "ref=\${ref}"
            echo "sha=\${sha}"
          } >> "\${GITHUB_OUTPUT}"

      - name: Checkout promotion router
        uses: actions/checkout@v7.0.0
        with:
          repository: \${{ steps.router.outputs.repository }}
          ref: \${{ steps.router.outputs.sha }}
          path: .buildchain/router
          persist-credentials: false

      - name: Resolve promotion channel
        id: route
        shell: bash
        run: >-
          node .buildchain/router/scripts/promotion-channel-router.mjs
          --cwd .buildchain/router
          --channel "\${{ inputs.buildchain-channel }}"
          --buildchain-ref "\${{ inputs.buildchain-ref }}"
          --publication-channel "\${{ inputs.channel }}"
          --target-ref "\${{ inputs.target-ref || github.ref_name }}"
          --router-ref "\${{ steps.router.outputs.ref }}"
          --router-sha "\${{ steps.router.outputs.sha }}"

      - name: Authorize trusted runtime override
        if: \${{ steps.route.outputs.override-used == 'true' }}
        uses: actions/github-script@v8
        with:
          script: |
            const script = require(process.env.GITHUB_WORKSPACE + "/.buildchain/router/scripts/authorize-promotion-runtime-override.cjs");
            await script.authorizePromotionRuntimeOverride({ github, context });

      - name: Resolve immutable promotion identities
        id: identities
        shell: bash
        env:
          GITHUB_TOKEN: \${{ github.token }}
          SELECTED_SHELL_REF: ${alphaRoute.logicalRef}
        run: |
          set -euo pipefail
          node .buildchain/router/scripts/promotion-identity-resolver.mjs \\
            --repository "\${{ steps.router.outputs.repository }}" \\
            --router-ref "\${{ steps.router.outputs.ref }}" \\
            --router-sha "\${{ steps.router.outputs.sha }}" \\
            --shell-ref "\${SELECTED_SHELL_REF}" \\
            --shell-call-ref "\${SELECTED_SHELL_REF}" \\
            --runtime-ref "\${{ steps.route.outputs.runtime-ref }}"
          echo "shell-ref=\${SELECTED_SHELL_REF}" >> "$GITHUB_OUTPUT"

      - name: Checkout selected promotion workflow shell
        uses: actions/checkout@v7.0.0
        with:
          repository: \${{ steps.router.outputs.repository }}
          ref: \${{ steps.identities.outputs.shell-sha }}
          path: .buildchain/shell
          persist-credentials: false

      - name: Checkout selected Buildchain runtime
        uses: actions/checkout@v7.0.0
        with:
          repository: \${{ steps.router.outputs.repository }}
          ref: \${{ steps.identities.outputs.runtime-sha }}
          path: .buildchain/runtime
          persist-credentials: false

      - name: Checkout promotion source
        uses: actions/checkout@v7.0.0
        with:
          ref: \${{ inputs.target-sha || github.sha }}
          path: .buildchain/source
          persist-credentials: false

      - name: Select and verify consumer contract lock
        id: lock
        shell: bash
        env:
          EXPLICIT_PATH: \${{ inputs.buildchain-contract-lock-path }}
          ALPHA_PATH: \${{ inputs.buildchain-alpha-contract-lock-path }}
          STABLE_PATH: \${{ inputs.buildchain-stable-contract-lock-path }}
          CHANNEL: \${{ steps.route.outputs.channel }}
        run: |
          set -euo pipefail
          path="\${EXPLICIT_PATH}"
          if [[ -z "\${path}" ]]; then
            if [[ "\${CHANNEL}" = "alpha" ]]; then path="\${ALPHA_PATH}"; else path="\${STABLE_PATH}"; fi
          fi
          if [[ -z "\${path}" || ! -f ".buildchain/source/\${path}" ]]; then
            echo "::error::Selected promotion contract lock is missing: \${path:-<empty>}"
            exit 1
          fi
          digest="sha256:$(shasum -a 256 ".buildchain/source/\${path}" | awk '{print $1}')"
          echo "path=\${path}" >> "\${GITHUB_OUTPUT}"
          echo "digest=\${digest}" >> "\${GITHUB_OUTPUT}"

      - name: Verify immutable promotion checkouts
        shell: bash
        env:
          SHELL_WORKFLOW_PATH: ${alphaRoute.workflowPath}
          ROUTER_SHA: \${{ steps.router.outputs.sha }}
          SHELL_SHA: \${{ steps.identities.outputs.shell-sha }}
          RUNTIME_SHA: \${{ steps.identities.outputs.runtime-sha }}
        run: |
          set -euo pipefail
          test -f ".buildchain/shell/\${SHELL_WORKFLOW_PATH}"
          [[ "$(git -C .buildchain/router rev-parse HEAD)" = "\${ROUTER_SHA}" ]] || { echo "::error::Promotion router checkout moved"; exit 1; }
          [[ "$(git -C .buildchain/shell rev-parse HEAD)" = "\${SHELL_SHA}" ]] || { echo "::error::Promotion shell checkout moved"; exit 1; }
          [[ "$(git -C .buildchain/runtime rev-parse HEAD)" = "\${RUNTIME_SHA}" ]] || { echo "::error::Promotion runtime checkout moved"; exit 1; }

${consumerAdmissionJob()}
  invoke:
    name: Invoke the single v4 publisher adapter
    needs: [resolve-promotion, consumer-admission]
    uses: kungfu-systems/buildchain/${alphaRoute.workflowPath}@${alphaRoute.callRef}
    permissions:
      actions: write
      artifact-metadata: write
      attestations: write
      checks: write
      contents: write
      id-token: write
      issues: write
      pull-requests: write
    with:
${invokeForwarded}
    secrets: inherit
`;
}

function main() {
  const source = fs.readFileSync(sourcePath, "utf8");
  const version = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8")).version;
  const major = Number(String(version).match(/^(\d+)\./)?.[1]);
  if (!Number.isInteger(major)) throw new Error("package version must expose a numeric major");
  const shellRouting = parsePromotionShellRouting(fs.readFileSync(routingPath, "utf8"), { major });
  const generated = generateChannelPromotionWorkflow(source, { major, shellRouting });
  if (process.argv.includes("--check")) {
    const current = fs.existsSync(targetPath) ? fs.readFileSync(targetPath, "utf8") : "";
    if (current !== generated) {
      console.error(".github/workflows/release-candidate-promote.yml is stale; run node scripts/generate-channel-promotion-workflow.mjs");
      process.exitCode = 1;
    }
    return;
  }
  fs.writeFileSync(targetPath, generated);
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) main();
