#!/usr/bin/env node
import { pathToFileURL } from "node:url";
import {
  resolveArtifactContract,
  resolveRunnerMatrix,
  writeGitHubOutputs,
} from "./build-contract-core.mjs";

function readArg(name, fallback = "") {
  const index = process.argv.indexOf(`--${name}`);
  if (index === -1) {
    return fallback;
  }
  return process.argv[index + 1] || "";
}

export function resolveBuildContractCli() {
  const mode = readArg(
    "mode",
    process.env.BUILDCHAIN_CONTRACT_MODE || "artifact",
  );
  if (mode === "runners") {
    const resolved = resolveRunnerMatrix({
      runnerPreset: process.env.BUILDCHAIN_RUNNER_PRESET || "github-hosted",
      platformsJson: process.env.BUILDCHAIN_PLATFORMS_JSON || "",
      awsCodeBuildProject:
        process.env.BUILDCHAIN_AWS_CODEBUILD_PROJECT || "",
      awsEc2WindowsRunnerLabel:
        process.env.BUILDCHAIN_AWS_EC2_WINDOWS_RUNNER_LABEL || "",
      awsEc2MacosRunnerLabel:
        process.env.BUILDCHAIN_AWS_EC2_MACOS_RUNNER_LABEL || "",
      linuxContainerPreset: process.env.BUILDCHAIN_LINUX_CONTAINER_PRESET || "",
      linuxContainerImage: process.env.BUILDCHAIN_LINUX_CONTAINER_IMAGE || "",
    });
    writeGitHubOutputs({
      "runner-preset": resolved.runnerPreset,
      "platforms-json": resolved.platformsJson,
      "platform-count": String(resolved.platformCount),
      "platform-source": resolved.source,
      "native-platforms-json": resolved.nativePlatformsJson,
      "native-platform-count": String(resolved.nativePlatformCount),
      "container-platforms-json": resolved.containerPlatformsJson,
      "container-platform-count": String(resolved.containerPlatformCount),
      "github-hosted-platforms-json": resolved.githubHostedPlatformsJson,
      "github-hosted-platform-ids-json": resolved.githubHostedPlatformIdsJson,
      "github-hosted-platform-count": String(
        resolved.githubHostedPlatformCount,
      ),
      "relay-platforms-json": resolved.relayPlatformsJson,
      "relay-platform-count": String(resolved.relayPlatformCount),
      "linux-container-enabled": String(resolved.linuxContainer.enabled),
      "linux-container-preset": resolved.linuxContainer.preset,
      "linux-container-image": resolved.linuxContainer.image,
      "linux-container-source": resolved.linuxContainer.source,
    });
    return resolved;
  }
  if (mode === "artifact") {
    const resolved = resolveArtifactContract({
      artifactName:
        process.env.BUILDCHAIN_ARTIFACT_NAME || "buildchain-artifact",
      artifactNameTemplate:
        process.env.BUILDCHAIN_ARTIFACT_NAME_TEMPLATE ||
        "{artifact}-{platform}-{sha}",
      platformId: process.env.BUILDCHAIN_PLATFORM_ID || "",
      platformName: process.env.BUILDCHAIN_PLATFORM_NAME || "",
      sha: process.env.BUILDCHAIN_SOURCE_SHA || process.env.GITHUB_SHA || "",
      ref: process.env.GITHUB_REF || "",
      runId: process.env.GITHUB_RUN_ID || "",
      runAttempt: process.env.GITHUB_RUN_ATTEMPT || "",
    });
    writeGitHubOutputs({
      "artifact-name": resolved.artifactName,
      "artifact-base-name": resolved.artifactBaseName,
      "artifact-name-template": resolved.artifactNameTemplate,
      "platform-id": resolved.platform.id,
      "platform-name": resolved.platform.name,
    });
    return resolved;
  }
  throw new Error(`unsupported build contract mode: ${mode}`);
}

if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  try {
    resolveBuildContractCli();
  } catch (error) {
    console.error(
      `::error::${String(error.message || error).replace(/\r?\n/g, "%0A")}`,
    );
    process.exitCode = 1;
  }
}
